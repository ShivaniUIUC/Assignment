package org.nice;

import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class WordFrequencyTest {

    private final String TEST_PATH = "src/test/resources/";

    @Test
    void testCalculateWordFrequency_no_freq_repetitions() throws IOException {
        WordFrequency wordFrequency = new WordFrequency("basic_input.txt", "noFreqRepetitionsOutput_Actual.txt");
        wordFrequency.calculateWordFrequency(Optional.of(TEST_PATH));
        File outputFile = new File(TEST_PATH+ "noFreqRepetitionsOutput_Actual.txt");
        assertTrue(outputFile.exists());
        String expectedOutput = new String(Files.readAllBytes(Paths.get(TEST_PATH+"noFreqRepetitionsOutput_Expected.txt")));
        assertEquals(expectedOutput, new String(Files.readAllBytes(Paths.get(TEST_PATH+ "noFreqRepetitionsOutput_Actual.txt"))));
    }


    @Test
    void testCalculateWordFrequency_with_freq_repetitions() throws IOException {
        WordFrequency wordFrequency = new WordFrequency("input.txt", "freqRepetitionsExist_Actual.txt");
        wordFrequency.calculateWordFrequency(Optional.of(TEST_PATH));
        File outputFile = new File(TEST_PATH+ "freqRepetitionsExist_Actual.txt");
        assertTrue(outputFile.exists());
        Path actualOpPath = Paths.get(TEST_PATH + "freqRepetitionsExist_Actual.txt");
        Path expectedOpPath = Paths.get(TEST_PATH + "freqRepetitionsExist_Expected.txt");
        // Test the lengths of the lists before converting to sets - to ensure there are no repeated values that are being ignored by the set.
        assertEquals(new String(Files.readAllBytes(expectedOpPath)).split("\n").length, new String(Files.readAllBytes(actualOpPath)).split("\n").length);
        Set<String> expectedOutput = Set.of(new String(Files.readAllBytes(expectedOpPath)).split("\n"));
        Set<String> actualOutput = Set.of(new String(Files.readAllBytes(actualOpPath)).split("\n"));
        assertEquals(expectedOutput, actualOutput);
    }


    @Test
    void testTokenize() {
        WordFrequency wordFrequency = new WordFrequency("input.txt", "output.txt");
        HashMap<String, Integer> wordFrequencies = new HashMap<>();
        String rawFileContents = "This is only a test. A *very* short test! ***f!rst,time$$$ BiGnSmAlL bignsmall @bignSMall!";
        wordFrequencies = wordFrequency.tokenize(rawFileContents, wordFrequencies);
        assertEquals(9, wordFrequencies.size());
        assertEquals(1, wordFrequencies.get("this"));
        assertEquals(1, wordFrequencies.get("is"));
        assertEquals(1, wordFrequencies.get("only"));
        assertEquals(2, wordFrequencies.get("a"));
        assertEquals(2, wordFrequencies.get("test"));
        assertEquals(1, wordFrequencies.get("very"));
        assertEquals(1, wordFrequencies.get("short"));
        assertEquals(1, wordFrequencies.get("**f!rst,time$$"));
        assertEquals(3, wordFrequencies.get("bignsmall"));
    }



}