package org.nice;

import org.nice.utils.HelperUtils;

import java.io.IOException;
import java.util.*;

public class WordFrequency {

    private final String PUNCTUATION_DELIMITERS = "!,@#$%^&*()~;:\"\'.";
    private final String inputFileName;
    private final String outputFileName;

    public WordFrequency(String inputFileName, String outputFileName) {
        this.inputFileName = inputFileName;
        this.outputFileName = outputFileName;
    }

    public List<String> fetchFileNames() throws IOException {
       return List.of(HelperUtils.getFileContents(this.inputFileName).split("\n"));
    }

    public void calculateWordFrequency(Optional<String> outputPath) throws IOException {
        HashMap<String, Integer> wordFrequencies = new HashMap<>();
        List<String> fileNames = fetchFileNames();
        for(String file: fileNames) {
            String rawFileContents = HelperUtils.getFileContents(file);
            wordFrequencies = tokenize(rawFileContents, wordFrequencies);
        }
        List<Map.Entry<String, Integer>> sortedFrequencies = HelperUtils.sortMapByValue(wordFrequencies);
        HelperUtils.writeOutputFile(sortedFrequencies, outputFileName, outputPath);
    }

    public HashMap<String, Integer> tokenize(String rawFileContents,  HashMap<String, Integer> wordFrequencies) {
        rawFileContents= rawFileContents.replace("\n", " ");
        StringTokenizer tokenizer = new StringTokenizer(rawFileContents, " ");
        while (tokenizer.hasMoreTokens()) {
            StringBuilder token = new StringBuilder(tokenizer.nextToken().toLowerCase().strip());
            if(PUNCTUATION_DELIMITERS.contains(String.valueOf(token.charAt(0))))
                token.deleteCharAt(0);
            if(PUNCTUATION_DELIMITERS.contains(String.valueOf(token.charAt(token.length()-1))))
                token.deleteCharAt(token.length()-1);
            wordFrequencies.put(token.toString(), wordFrequencies.getOrDefault(token.toString(), 0) + 1);
        }
        return wordFrequencies;
    }


}
