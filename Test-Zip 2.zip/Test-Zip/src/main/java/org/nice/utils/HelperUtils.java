package org.nice.utils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

public class HelperUtils {

    private static final String FILE_PATH = "src/main/resources/inputFiles/";
    private static final String OUTPUT_PATH = "src/main/resources/";
    public static String getFileContents(String fileName) throws IOException {
        String file = FILE_PATH + fileName;
        return new String(Files.readAllBytes(Paths.get(file)));
    }

    public static void writeOutputFile(List<Map.Entry<String, Integer>> wordFrequency, String fileName, Optional<String> outputPath) throws IOException {
        try (BufferedWriter br = new BufferedWriter(new FileWriter(outputPath.isEmpty() ? OUTPUT_PATH + fileName : outputPath.get() + fileName))){
            for (Map.Entry<String, Integer> entry : wordFrequency) {
                br.write(entry.getKey() + " " + entry.getValue());
                br.newLine();
            }
        } catch (IOException e) {
           System.out.println("Failed to write output to file: " + e);
        }
    }

    public static List<Map.Entry<String, Integer>> sortMapByValue(HashMap<String, Integer> map) {
        return map.entrySet().stream().sorted(Map.Entry.<String, Integer>comparingByValue().reversed()).collect(Collectors.toList());
    }
}
