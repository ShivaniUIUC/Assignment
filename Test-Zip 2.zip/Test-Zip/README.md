### Environment
1. Java v21.0.2
2. Gradle v8.6

### Input Files
1. For both the application and Unit Tests: src/main/resources/inputFiles
2. Expected Output Files for Unit Tests: src/test/resources

## Types of Input Files:
1. input.txt (1.txt, 2.txt, 3.txt) - Comprehensive test (Corresponds to this test: testCalculateWordFrequency_with_freq_repetitions
2. basic_input.txt (basic_input_1.txt, basic_input_2.txt) - Simple test without any repetitions in the frequency (Corresponds to this test: testCalculateWordFrequency_with_freq_repetitions)
3. If you want to add a new input file, please add it to "src/main/resources/inputFiles"